package ysoserial.test;


/**
 * @author mbechler
 *
 */
public interface CustomPayloadArgs {


    String getPayloadArgs ();

}
