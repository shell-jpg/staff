package ysoserial.payloads;


/**
 * @author mbechler
 *
 */
public interface DynamicDependencies {

}
